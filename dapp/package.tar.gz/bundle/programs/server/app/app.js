var require = meteorInstall({"lib":{"lib.js":function(){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// lib/lib.js                                                                      //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
if (Meteor.isServer) {} else {
    if (typeof web3 !== 'undefined') {
        web3 = new Web3(web3.currentProvider);
    } else {
        // set the provider you want from Web3.providers
        web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
    }
}
/////////////////////////////////////////////////////////////////////////////////////

}},"server":{"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////
//                                                                                 //
// server/main.js                                                                  //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
                                                                                   //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
SavedRolls = new Mongo.Collection('savedRolls');
SavedCandidates = new Mongo.Collection('savedCandidates');
Meteor.startup(() => {// code to run on server at startup
});
/////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/lib.js");
require("./server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2xpYi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwiaXNTZXJ2ZXIiLCJ3ZWIzIiwiV2ViMyIsImN1cnJlbnRQcm92aWRlciIsInByb3ZpZGVycyIsIkh0dHBQcm92aWRlciIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsInYiLCJTYXZlZFJvbGxzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiU2F2ZWRDYW5kaWRhdGVzIiwic3RhcnR1cCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxPQUFPQyxRQUFYLEVBQXFCLENBRXBCLENBRkQsTUFFTztBQUNILFFBQUksT0FBT0MsSUFBUCxLQUFnQixXQUFwQixFQUFpQztBQUM3QkEsZUFBTyxJQUFJQyxJQUFKLENBQVNELEtBQUtFLGVBQWQsQ0FBUDtBQUNILEtBRkQsTUFFTztBQUNIO0FBQ0FGLGVBQU8sSUFBSUMsSUFBSixDQUFTLElBQUlBLEtBQUtFLFNBQUwsQ0FBZUMsWUFBbkIsQ0FBZ0MsdUJBQWhDLENBQVQsQ0FBUDtBQUNIO0FBQ0osQzs7Ozs7Ozs7Ozs7QUNURCxJQUFJTixNQUFKO0FBQVdPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ1QsU0FBT1UsQ0FBUCxFQUFTO0FBQUNWLGFBQU9VLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFDWEMsYUFBWSxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLFlBQXJCLENBQVo7QUFDQUMsa0JBQWlCLElBQUlGLE1BQU1DLFVBQVYsQ0FBcUIsaUJBQXJCLENBQWpCO0FBRUFiLE9BQU9lLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0QsQ0FGRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpZiAoTWV0ZW9yLmlzU2VydmVyKSB7XG5cbn0gZWxzZSB7XG4gICAgaWYgKHR5cGVvZiB3ZWIzICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICB3ZWIzID0gbmV3IFdlYjMod2ViMy5jdXJyZW50UHJvdmlkZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIHNldCB0aGUgcHJvdmlkZXIgeW91IHdhbnQgZnJvbSBXZWIzLnByb3ZpZGVyc1xuICAgICAgICB3ZWIzID0gbmV3IFdlYjMobmV3IFdlYjMucHJvdmlkZXJzLkh0dHBQcm92aWRlcihcImh0dHA6Ly9sb2NhbGhvc3Q6ODU0NVwiKSk7XG4gICAgfVxufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuU2F2ZWRSb2xscz0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NhdmVkUm9sbHMnKTtcblNhdmVkQ2FuZGlkYXRlcz0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3NhdmVkQ2FuZGlkYXRlcycpO1xuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIGNvZGUgdG8gcnVuIG9uIHNlcnZlciBhdCBzdGFydHVwXG59KTtcbiJdfQ==
