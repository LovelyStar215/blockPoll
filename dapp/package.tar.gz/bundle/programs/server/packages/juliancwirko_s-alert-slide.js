(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['juliancwirko:s-alert-slide'] = {};

})();
